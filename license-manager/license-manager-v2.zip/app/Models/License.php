<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class License extends Model
{
    protected $fillable = [
        'license_key',
        'customer_name',
        'tier',
        'is_active',
        'expires_at',
        'machine_id',    // os.hostname()
        'machine_name',  // friendly name
        'hardware_id',   // Windows MachineGUID — the real hardware lock
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'expires_at' => 'datetime',
    ];

    public function activations(): HasMany
    {
        return $this->hasMany(Activation::class);
    }
}
